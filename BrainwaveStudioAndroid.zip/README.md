# استودیو خالص امواج مغزی — نسخه اندروید ۱۶ (API 36)

اپلیکیشن نیتیو اندروید ۱۶ ساخته شده با **Kotlin**، **Jetpack Compose (Material 3)** و موتور صوتی خالص **48kHz Stereo 32-bit Float PCM (`AudioTrack`)**.

## نحوه دریافت مستقیم فایل APK بدون نیاز به Android Studio (با GitHub Actions)

1. در سایت [GitHub.com](https://github.com) یک ریپازیتوری جدید (عمومی یا خصوصی) بسازید.
2. تمام فایل‌های پوشه `BrainwaveStudioAndroid` را در آن آپلود (Push) کنید.
3. وارد تب **Actions** در ریپازیتوری شوید؛ ورک‌فلو **Build Android 16 APK** به‌صورت خودکار اجرا می‌شود (یا می‌توانید دکمه **Run workflow** را بزنید).
4. پس از حدود ۲ تا ۳ دقیقه، در پایین صفحه همان اجرا، فایل **`BrainwaveStudio-Android16-APK`** را دانلود کرده، از حالت ZIP خارج کنید و فایل `app-debug.apk` را روی گوشی اندروید خود نصب کنید.

## نحوه بیلد در Android Studio

- پوشه `BrainwaveStudioAndroid` را مستقیماً در **Android Studio** باز کنید و از منوی `Build > Build Bundle(s) / APK(s) > Build APK(s)` خروجی بگیرید.
