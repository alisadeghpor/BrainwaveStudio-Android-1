package com.brainwavestudio.app.audio

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.brainwavestudio.app.model.AmbientType
import com.brainwavestudio.app.model.AudioMode
import com.brainwavestudio.app.model.StudioState
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * Renders studio-quality 48kHz 16-bit Stereo WAV directly into Music/BrainwaveStudio/
 */
object WavExporter {
    fun exportWav(context: Context, state: StudioState, durationMinutes: Int): Result<String> {
        return runCatching {
            val sampleRate = 48000
            val totalFrames = sampleRate * durationMinutes * 60
            val fileName = "Brainwave_${state.mode.name}_${String.format("%.1f", state.beatHz)}Hz_${durationMinutes}min.wav"

            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/BrainwaveStudio")
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("امکان ایجاد فایل در حافظه وجود ندارد.")

            resolver.openOutputStream(uri)?.use { out ->
                writeWavHeader(out, totalFrames, sampleRate, 2, 16)
                renderSamples(out, state, totalFrames, sampleRate)
            } ?: error("خطا در باز کردن خروجی فایل.")

            "Music/BrainwaveStudio/$fileName"
        }
    }

    private fun writeWavHeader(out: OutputStream, totalFrames: Int, sampleRate: Int, channels: Int, bitsPerSample: Int) {
        val dataSize = totalFrames * channels * (bitsPerSample / 8)
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = (channels * (bitsPerSample / 8)).toShort()

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + dataSize)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1) // PCM
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(blockAlign)
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray())
        header.putInt(dataSize)
        out.write(header.array())
    }

    private fun renderSamples(out: OutputStream, st: StudioState, totalFrames: Int, sampleRate: Int) {
        val twoPi = 2.0 * PI
        val leftHz = maxOf(20.0, st.carrierHz - st.beatHz / 2.0)
        val rightHz = maxOf(20.0, st.carrierHz + st.beatHz / 2.0)
        val binMix = when (st.mode) { AudioMode.BINAURAL -> 0.60; AudioMode.HYBRID -> 0.38; AudioMode.ISOCHRONIC -> 0.0 }
        val isoMix = when (st.mode) { AudioMode.ISOCHRONIC -> 0.60; AudioMode.HYBRID -> 0.36; AudioMode.BINAURAL -> 0.0 }
        val isoDepth = st.isoDepth.toDouble()
        val warmthGain = st.warmth.toDouble() * 0.22
        val masterGain = st.masterVol.toDouble() * 0.65
        val ambientGain = if (st.ambientType == AmbientType.NONE) 0.0 else st.ambientVol.toDouble() * 0.45

        val fadeFrames = sampleRate * 2 // 2s fade in & out
        val chunkFrames = 4096
        val bytes = ByteArray(chunkFrames * 4)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val rng = Random.Default
        var brownL = 0.0; var brownR = 0.0

        var frame = 0
        while (frame < totalFrames) {
            val count = minOf(chunkFrames, totalFrames - frame)
            bb.clear()
            for (i in 0 until count) {
                val n = frame + i
                val t = n.toDouble() / sampleRate
                val fade = when {
                    n < fadeFrames -> n.toDouble() / fadeFrames
                    n > totalFrames - fadeFrames -> (totalFrames - n).toDouble() / fadeFrames
                    else -> 1.0
                }
                val sinL = sin(twoPi * leftHz * t)
                val sinR = sin(twoPi * rightHz * t)
                val lfoMod = (1.0 - isoDepth / 2.0) + (isoDepth / 2.0) * sin(twoPi * st.beatHz * t)
                val isoS = sin(twoPi * st.carrierHz * t) * lfoMod
                val warmS = sin(twoPi * maxOf(40.0, st.carrierHz / 2.0) * t) * warmthGain

                var ambL = 0.0; var ambR = 0.0
                if (ambientGain > 0.0001) {
                    val wL = rng.nextDouble(-1.0, 1.0); val wR = rng.nextDouble(-1.0, 1.0)
                    brownL = (brownL + 0.02 * wL) / 1.02
                    brownR = (brownR + 0.02 * wR) / 1.02
                    ambL = if (st.ambientType == AmbientType.BROWN) brownL * 1.4 else wL * 0.12
                    ambR = if (st.ambientType == AmbientType.BROWN) brownR * 1.4 else wR * 0.12
                }

                val outL = tanh((sinL * binMix + isoS * isoMix + warmS + ambL * ambientGain) * masterGain * fade)
                val outR = tanh((sinR * binMix + isoS * isoMix + warmS + ambR * ambientGain) * masterGain * fade)

                bb.putShort((outL * 32767.0).toInt().coerceIn(-32768, 32767).toShort())
                bb.putShort((outR * 32767.0).toInt().coerceIn(-32768, 32767).toShort())
            }
            out.write(bytes, 0, count * 4)
            frame += count
        }
    }
}
