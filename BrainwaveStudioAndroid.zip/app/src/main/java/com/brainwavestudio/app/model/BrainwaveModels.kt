package com.brainwavestudio.app.model

import androidx.compose.ui.graphics.Color

enum class AudioMode(val titleFa: String, val subtitleFa: String) {
    BINAURAL("بینورال بیت", "دوگوشی خالص (نیازمند هدفون)"),
    ISOCHRONIC("ایزوکرونیک", "پالس نرم سینوسی (هدفون/اسپیکر)"),
    HYBRID("ترکیبی", "دوگوشی + ایزوکرونیک همزمان")
}

enum class AmbientType(val titleFa: String) {
    NONE("خاموش (خالص)"),
    PINK("باران ملایم"),
    BROWN("اقیانوس عمیق"),
    WHITE("نسیم آرام")
}

data class BrainwavePreset(
    val id: String,
    val band: String,
    val nameFa: String,
    val beatHz: Float,
    val carrierHz: Float,
    val color: Color,
    val descriptionFa: String
)

data class JourneyPreset(
    val nameFa: String,
    val startHz: Float,
    val endHz: Float,
    val durationMin: Int,
    val carrierHz: Float,
    val descriptionFa: String
)

data class SavedCustomPreset(
    val name: String,
    val beatHz: Float,
    val carrierHz: Float,
    val mode: AudioMode,
    val isoDepth: Float,
    val warmth: Float,
    val ambientType: AmbientType,
    val ambientVol: Float
)

data class StudioState(
    val isPlaying: Boolean = false,
    val mode: AudioMode = AudioMode.BINAURAL,
    val beatHz: Float = 10.0f,
    val carrierHz: Float = 216f,
    val isoDepth: Float = 0.85f,
    val masterVol: Float = 0.50f,
    val warmth: Float = 0.10f,
    val ambientType: AmbientType = AmbientType.NONE,
    val ambientVol: Float = 0.25f,
    val activePresetId: String? = "alpha-mid",
    val activeTitle: String = "آلفا میانی — تمرکز آرام و مطالعه",
    val timerMinutes: Int = 15,
    val remainingSeconds: Int = 15 * 60,
    val rampActive: Boolean = false,
    val rampProgress: Float = 0f,
    val accentColor: Color = Color(0xFF34D399)
)

object BrainwaveCatalog {
    val solfeggioCarriers = listOf(128f, 174f, 216f, 285f, 396f, 417f, 432f, 528f, 639f, 741f, 852f, 963f)

    val presets = listOf(
        BrainwavePreset("epsilon-deep", "اپسیلون", "اپسیلون عمیق (Infra-Low)", 0.3f, 128f, Color(0xFFA855F7), "مدیتیشن بسیار عمیق، آرامش کامل سیستم عصبی و همگام‌سازی درونی."),
        BrainwavePreset("delta-deep", "دلتا", "دلتا عمیق — خواب بدون رویا", 1.5f, 144f, Color(0xFF6366F1), "عمیق‌ترین مرحله خواب، بازسازی سلولی و ریکاوری جسمی شبانه."),
        BrainwavePreset("delta-high", "دلتا", "دلتا بالا — آرامش و تسکین", 3.0f, 174f, Color(0xFF818CF8), "خواب عمیق آرام‌بخش، کاهش تنش بدنی و ورود نرم به خواب."),
        BrainwavePreset("theta-low", "تتا", "تتا پایین — مدیتیشن عمیق", 4.5f, 192f, Color(0xFF06B6D4), "حالت نیمه‌خواب و مدیتیشن عمیق، کاهش شدید استرس و آرامش درونی."),
        BrainwavePreset("theta-high", "تتا", "تتا بالا — خلاقیت و شهود", 6.5f, 216f, Color(0xFF22D3EE), "تقویت تجسم خلاق، ایده‌پردازی، حافظه عاطفی و یادگیری عمیق."),
        BrainwavePreset("schumann", "تتا", "رزونانس شومان (فرکانس زمین)", 7.83f, 216f, Color(0xFF14B8A6), "فرکانس طبیعی تشدید زمین در مرز تتا و آلفا؛ متعادل‌کننده ذهن."),
        BrainwavePreset("alpha-low", "آلفا", "آلفا پایین — ریلکسیشن و ضد اضطراب", 8.5f, 216f, Color(0xFF38BDF8), "آرامش بیدار، رفع تنش روزانه، کاهش اضطراب و تعادل ذهنی."),
        BrainwavePreset("alpha-mid", "آلفا", "آلفا میانی — تمرکز آرام و مطالعه", 10.0f, 216f, Color(0xFF34D399), "بهترین فرکانس برای مطالعه آرام، یادگیری بدون استرس و حالت جریان."),
        BrainwavePreset("alpha-high", "آلفا", "آلفا بالا — شفافیت و آمادگی ذهنی", 11.5f, 256f, Color(0xFF10B981), "پل بین آرامش و تمرکز فعال؛ مناسب برای شروع کارهای فکری."),
        BrainwavePreset("beta-smr", "بتا", "بتا پایین (SMR) — تمرکز آرام", 14.0f, 285f, Color(0xFFF59E0B), "ریتم حسی-حرکتی؛ هوشیاری آرام و بهبود تمرکز پایدار."),
        BrainwavePreset("beta-mid", "بتا", "بتا میانی — حل مسئله و کار فعال", 18.0f, 320f, Color(0xFFFB923C), "تفکر منطقی، تحلیل، برنامه‌نویسی، کار روزانه و انرژی ذهنی متعادل."),
        BrainwavePreset("beta-high", "بتا", "بتا بالا — هوشیاری و پردازش سریع", 24.0f, 396f, Color(0xFFF97316), "انرژی ذهنی بالا برای جلسات کوتاه (۱۰ تا ۱۵ دقیقه)."),
        BrainwavePreset("gamma-40", "گاما", "گاما ۴۰ هرتز — اوج تمرکز و حافظه", 40.0f, 432f, Color(0xFFEC4899), "مشهورترین فرکانس گاما برای یکپارچگی شناختی، حافظه و تمرکز عمیق."),
        BrainwavePreset("gamma-high", "گاما", "هایپرگاما — پردازش و بینش متعالی", 70.0f, 528f, Color(0xFFF43F5E), "موج گامای بالا برای مدیتیشن‌های تمرکزی پیشرفته و شفافیت ذهنی.")
    )

    val journeys = listOf(
        JourneyPreset("ورود تدریجی به خواب عمیق", 10f, 2f, 20, 174f, "شروع از آلفای آرام‌بخش و نزول بسیار نرم به دلتای عمیق."),
        JourneyPreset("مدیتیشن عمیق از ذهن فعال", 14f, 4.5f, 15, 216f, "آرام‌سازی تدریجی ذهن پرمشغله و ورود به تتای عمیق."),
        JourneyPreset("بیداری و تمرکز صبحگاهی", 6f, 18f, 10, 285f, "ارتقای تدریجی از حالت خواب‌آلودگی به هوشیاری و تمرکز فعال."),
        JourneyPreset("صعود به اوج تمرکز گاما (40 Hz)", 10f, 40f, 12, 432f, "شروع از تمرکز آرام آلفا و رسیدن به اوج یکپارچگی شناختی.")
    )

    fun bandNameFor(hz: Float): String = when {
        hz < 0.5f -> "Epsilon"
        hz < 4f -> "Delta"
        hz < 8f -> "Theta"
        hz < 12f -> "Alpha"
        hz < 30f -> "Beta"
        else -> "Gamma"
    }
}
