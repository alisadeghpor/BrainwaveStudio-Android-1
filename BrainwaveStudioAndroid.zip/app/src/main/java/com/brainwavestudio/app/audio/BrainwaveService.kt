package com.brainwavestudio.app.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.brainwavestudio.app.MainActivity

class BrainwaveService : Service() {

    companion object {
        const val CHANNEL_ID = "brainwave_playback_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.brainwavestudio.app.START"
        const val ACTION_STOP = "com.brainwavestudio.app.STOP"

        fun startPlayback(context: Context) {
            val intent = Intent(context, BrainwaveService::class.java).apply { action = ACTION_START }
            context.startForegroundService(intent)
        }

        fun stopPlayback(context: Context) {
            val intent = Intent(context, BrainwaveService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                PureBrainwaveEngine.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                createChannel()
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                PureBrainwaveEngine.start()
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "پخش امواج مغزی",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "نمایش وضعیت پخش زنده بینورال بیت و ایزوکرونیک"
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val st = PureBrainwaveEngine.state.value
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, BrainwaveService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("استودیو امواج مغزی • ${st.mode.titleFa}")
            .setContentText("${st.activeTitle} (${String.format("%.2f", st.beatHz)} Hz)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "توقف", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        PureBrainwaveEngine.stop()
        super.onDestroy()
    }
}
