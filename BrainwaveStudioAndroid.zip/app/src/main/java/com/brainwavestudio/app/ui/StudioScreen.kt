package com.brainwavestudio.app.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.brainwavestudio.app.audio.BrainwaveService
import com.brainwavestudio.app.audio.PureBrainwaveEngine
import com.brainwavestudio.app.audio.WavExporter
import com.brainwavestudio.app.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StudioRootScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by PureBrainwaveEngine.state.collectAsState()
    val waveform by PureBrainwaveEngine.waveform.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🎛️ استودیو", "🌊 سفر فرکانسی", "💾 خروجی WAV", "📘 راهنما")

    // Session countdown timer
    LaunchedEffect(state.isPlaying, state.timerMinutes) {
        if (state.isPlaying && state.timerMinutes > 0) {
            while (PureBrainwaveEngine.state.value.isPlaying && PureBrainwaveEngine.state.value.remainingSeconds > 0) {
                delay(1000)
                PureBrainwaveEngine.updateState { it.copy(remainingSeconds = (it.remainingSeconds - 1).coerceAtLeast(0)) }
                if (PureBrainwaveEngine.state.value.remainingSeconds == 0) {
                    BrainwaveService.stopPlayback(context)
                    PureBrainwaveEngine.updateState { it.copy(remainingSeconds = it.timerMinutes * 60) }
                }
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFF060A13),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "استودیو خالص امواج مغزی",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = "اندروید ۱۶ • موتور صوتی 48kHz Float PCM • بینورال و ایزوکرونیک",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tabs.forEachIndexed { idx, title ->
                        val active = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (active) state.accentColor else Color(0xFF111A2E))
                                .clickable { selectedTab = idx }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (active) Color(0xFF030712) else Color(0xFFCBD5E1)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> StudioMainTab(context, state, waveform)
                1 -> JourneyRampTab(context, state, scope)
                2 -> ExportAndPresetsTab(context, state, scope)
                3 -> GuideAndSafetyTab()
            }
        }
    }
}

@Composable
private fun StudioMainTab(context: Context, state: StudioState, waveform: FloatArray) {
    var bandFilter by remember { mutableStateOf("همه") }
    val bands = listOf("همه", "اپسیلون", "دلتا", "تتا", "آلفا", "بتا", "گاما")
    val filteredPresets = remember(bandFilter) {
        if (bandFilter == "همه") BrainwaveCatalog.presets
        else BrainwaveCatalog.presets.filter { it.band == bandFilter }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Live Visualizer + Play Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(state.activeTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                        Text(
                            "${BrainwaveCatalog.bandNameFor(state.beatHz)} • ${String.format("%.2f", state.beatHz)} Hz",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = state.accentColor
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    // Oscilloscope Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF050811))
                    ) {
                        val midY = size.height / 2f
                        drawLine(
                            color = Color(0x2294A3B8),
                            start = Offset(0f, midY),
                            end = Offset(size.width, midY),
                            strokeWidth = 1f
                        )
                        val path = Path()
                        val step = size.width / (waveform.size - 1).coerceAtLeast(1)
                        waveform.forEachIndexed { idx, sample ->
                            val x = idx * step
                            val y = midY - sample * (size.height * 0.42f)
                            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, color = state.accentColor, style = Stroke(width = 4f))
                    }

                    Spacer(Modifier.height(12.dp))

                    // Audio Mode Selector
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AudioMode.entries.forEach { m ->
                            val selected = state.mode == m
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (selected) state.accentColor.copy(alpha = 0.2f) else Color(0xFF17223B))
                                    .border(1.dp, if (selected) state.accentColor else Color(0x2294A3B8), RoundedCornerShape(12.dp))
                                    .clickable { PureBrainwaveEngine.updateState { it.copy(mode = m) } }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(m.titleFa, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Play / Stop + Stereo Test
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (state.isPlaying) BrainwaveService.stopPlayback(context)
                                else BrainwaveService.startPlayback(context)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.isPlaying) Color(0xFFEF4444) else state.accentColor,
                                contentColor = if (state.isPlaying) Color.White else Color(0xFF030712)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text(
                                if (state.isPlaying) "⏹ توقف نرم پخش" else "▶ شروع پخش خالص",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                        OutlinedButton(
                            onClick = { PureBrainwaveEngine.playStereoEarTest() },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("🎧 تست L/R", fontSize = 12.sp, color = Color.White)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Left / Beat / Right Readout
                    val leftHz = (state.carrierHz - state.beatHz / 2f).coerceAtLeast(20f)
                    val rightHz = (state.carrierHz + state.beatHz / 2f).coerceAtLeast(20f)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF080D1A))
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Text("چپ: ${String.format("%.1f", leftHz)} Hz", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                        Text("ضربان: ${String.format("%.2f", state.beatHz)} Hz", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = state.accentColor)
                        Text("راست: ${String.format("%.1f", rightHz)} Hz", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                    }

                    Spacer(Modifier.height(12.dp))

                    // Beat Frequency Slider
                    SliderRow("فرکانس موج مغزی", "${String.format("%.2f", state.beatHz)} Hz", state.beatHz, 0.1f..100f) { v ->
                        PureBrainwaveEngine.updateState {
                            it.copy(beatHz = v, activePresetId = null, activeTitle = "تنظیم دستی (${BrainwaveCatalog.bandNameFor(v)})")
                        }
                    }

                    // Carrier Frequency Slider + Solfeggio Chips
                    SliderRow("فرکانس حامل (Carrier)", "${state.carrierHz.toInt()} Hz", state.carrierHz, 60f..963f) { v ->
                        PureBrainwaveEngine.updateState { it.copy(carrierHz = v) }
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        BrainwaveCatalog.solfeggioCarriers.forEach { hz ->
                            val sel = state.carrierHz.toInt() == hz.toInt()
                            FilterChip(
                                selected = sel,
                                onClick = { PureBrainwaveEngine.updateState { it.copy(carrierHz = hz) } },
                                label = { Text("${hz.toInt()} Hz", fontSize = 11.sp) }
                            )
                        }
                    }

                    if (state.mode != AudioMode.BINAURAL) {
                        SliderRow("عمق پالس ایزوکرونیک", "${(state.isoDepth * 100).toInt()}%", state.isoDepth, 0.2f..1f) { v ->
                            PureBrainwaveEngine.updateState { it.copy(isoDepth = v) }
                        }
                    }

                    SliderRow("شدت صدای اصلی", "${(state.masterVol * 100).toInt()}%", state.masterVol, 0f..1f) { v ->
                        PureBrainwaveEngine.updateState { it.copy(masterVol = v) }
                    }

                    SliderRow("گرمای هارمونیک (اکتاو نرم)", "${(state.warmth * 100).toInt()}%", state.warmth, 0f..1f) { v ->
                        PureBrainwaveEngine.updateState { it.copy(warmth = v) }
                    }

                    // Ambient Natural Layer
                    Text("🌿 لایه صدای طبیعی پس‌زمینه", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AmbientType.entries.forEach { amb ->
                            FilterChip(
                                selected = state.ambientType == amb,
                                onClick = { PureBrainwaveEngine.updateState { it.copy(ambientType = amb) } },
                                label = { Text(amb.titleFa, fontSize = 11.sp) }
                            )
                        }
                    }
                    if (state.ambientType != AmbientType.NONE) {
                        SliderRow("شدت صدای طبیعی", "${(state.ambientVol * 100).toInt()}%", state.ambientVol, 0f..1f) { v ->
                            PureBrainwaveEngine.updateState { it.copy(ambientVol = v) }
                        }
                    }

                    // Timer Chips
                    Spacer(Modifier.height(6.dp))
                    val timerText = if (state.timerMinutes == 0) "نامحدود" else "${state.remainingSeconds / 60}:${String.format("%02d", state.remainingSeconds % 60)}"
                    Text("⏱️ تایمر جلسه: $timerText", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 5, 10, 15, 20, 30, 45, 60).forEach { m ->
                            FilterChip(
                                selected = state.timerMinutes == m,
                                onClick = { PureBrainwaveEngine.updateState { it.copy(timerMinutes = m, remainingSeconds = m * 60) } },
                                label = { Text(if (m == 0) "نامحدود" else "$m دقیقه", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Band Filter Header
        item {
            Text("🧠 انتخاب موج مغزی (تمام انواع)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                bands.forEach { b ->
                    FilterChip(
                        selected = bandFilter == b,
                        onClick = { bandFilter = b },
                        label = { Text(b, fontSize = 12.sp) }
                    )
                }
            }
        }

        // Presets List
        items(filteredPresets) { preset ->
            val active = state.activePresetId == preset.id
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (active) preset.color.copy(alpha = 0.18f) else Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (active) preset.color else Color(0x2294A3B8), RoundedCornerShape(14.dp))
                    .clickable {
                        PureBrainwaveEngine.updateState {
                            it.copy(
                                activePresetId = preset.id,
                                activeTitle = preset.nameFa,
                                beatHz = preset.beatHz,
                                carrierHz = preset.carrierHz,
                                accentColor = preset.color
                            )
                        }
                    }
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(preset.nameFa, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text("${preset.beatHz} Hz", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = preset.color)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(preset.descriptionFa, fontSize = 12.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}

@Composable
private fun JourneyRampTab(context: Context, state: StudioState, scope: kotlinx.coroutines.CoroutineScope) {
    var startHz by remember { mutableFloatStateOf(12f) }
    var endHz by remember { mutableFloatStateOf(2.5f) }
    var durationMin by remember { mutableFloatStateOf(15f) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("🌊 شیب فرکانسی خودکار (Frequency Ramp)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                Text("مغز را به نرمی از فرکانس شروع به فرکانس هدف هدایت می‌کند.", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(Modifier.height(12.dp))

                SliderRow("فرکانس شروع", "${String.format("%.1f", startHz)} Hz", startHz, 0.2f..60f) { startHz = it }
                SliderRow("فرکانس پایان", "${String.format("%.1f", endHz)} Hz", endHz, 0.2f..60f) { endHz = it }
                SliderRow("مدت انتقال", "${durationMin.toInt()} دقیقه", durationMin, 1f..60f) { durationMin = it }

                LinearProgressIndicator(
                    progress = { state.rampProgress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                    color = state.accentColor
                )
                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (!state.isPlaying) BrainwaveService.startPlayback(context)
                        PureBrainwaveEngine.updateState {
                            it.copy(rampActive = true, rampProgress = 0f, beatHz = startHz, activeTitle = "سفر فرکانسی (${startHz.toInt()}→${endHz.toInt()} Hz)")
                        }
                        scope.launch {
                            val totalSteps = (durationMin * 60 * 2).toInt().coerceAtLeast(1)
                            for (step in 1..totalSteps) {
                                if (!PureBrainwaveEngine.state.value.rampActive) break
                                delay(500)
                                val t = step.toFloat() / totalSteps
                                val hz = startHz + (endHz - startHz) * t
                                PureBrainwaveEngine.updateState { it.copy(beatHz = hz, rampProgress = t) }
                            }
                            PureBrainwaveEngine.updateState { it.copy(rampActive = false) }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (state.rampActive) "در حال اجرای سفر..." else "▶ شروع سفر فرکانسی", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("✨ سفرهای آماده تخصصی", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
        BrainwaveCatalog.journeys.forEach { j ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                    startHz = j.startHz; endHz = j.endHz; durationMin = j.durationMin.toFloat()
                    PureBrainwaveEngine.updateState { it.copy(carrierHz = j.carrierHz, beatHz = j.startHz, activeTitle = j.nameFa) }
                }
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(j.nameFa, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    Text("${j.startHz} ← ${j.endHz} Hz • ${j.durationMin} دقیقه", fontSize = 12.sp, color = state.accentColor)
                    Text(j.descriptionFa, fontSize = 12.sp, color = Color(0xFF94A3B8))
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ExportAndPresetsTab(context: Context, state: StudioState, scope: kotlinx.coroutines.CoroutineScope) {
    var exportMin by remember { mutableFloatStateOf(3f) }
    var exportMsg by remember { mutableStateOf("") }
    var exporting by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("🎧 خروجی فایل صوتی خالص WAV (48kHz Stereo)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                Text("تنظیمات فعلی استودیو را با کیفیت استودیویی در پوشه Music/BrainwaveStudio ذخیره می‌کند.", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(Modifier.height(10.dp))
                SliderRow("مدت فایل خروجی", "${exportMin.toInt()} دقیقه", exportMin, 1f..10f) { exportMin = it }

                Button(
                    enabled = !exporting,
                    onClick = {
                        exporting = true
                        exportMsg = "⏳ در حال رندر صوتی خالص..."
                        scope.launch {
                            val res = withContext(Dispatchers.IO) {
                                WavExporter.exportWav(context, state, exportMin.toInt())
                            }
                            exportMsg = res.fold(
                                onSuccess = { "✅ ذخیره شد در: $it" },
                                onFailure = { "❌ خطا: ${it.message}" }
                            )
                            exporting = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (exporting) "در حال تولید..." else "⬇ تولید و ذخیره فایل WAV", fontWeight = FontWeight.Bold)
                }
                if (exportMsg.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(exportMsg, fontSize = 12.sp, color = state.accentColor, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun GuideAndSafetyTab() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("🎧 راهنمای استفاده از امواج مغزی", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF38BDF8))
                Spacer(Modifier.height(6.dp))
                Text(
                    "• بینورال بیت (Binaural): نیازمند هدفون استریو است تا هر گوش فرکانس مجزا دریافت کند.\n" +
                    "• ایزوکرونیک (Isochronic): هم با هدفون و هم با اسپیکر کار می‌کند.\n" +
                    "• فرکانس حامل پایین‌تر (۱۲۸ تا ۲۱۶ هرتز) برای دلتا و تتا صدای گرم‌تر و طبیعی‌تری دارد.\n" +
                    "• شدت صدا را همیشه ملایم و راحت تنظیم کنید (۱۵ تا ۳۰ دقیقه در هر جلسه).",
                    fontSize = 13.sp, color = Color(0xFFCBD5E1), lineHeight = 22.sp
                )
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1218)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("⚠️ نکات ایمنی مهم", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFFF87171))
                Spacer(Modifier.height(6.dp))
                Text(
                    "• هنگام رانندگی یا کار با ماشین‌آلات هرگز از امواج خواب‌آور (دلتا، تتا، اپسیلون) استفاده نکنید.\n" +
                    "• افراد دارای سابقه صرع، تشنج یا دستگاه ضربان‌ساز قلب پیش از استفاده با پزشک مشورت کنند.\n" +
                    "• این اپلیکیشن دستیار آرامش و تمرکز است و جایگزین درمان پزشکی نیست.",
                    fontSize = 13.sp, color = Color(0xFFFECACA), lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = Color(0xFFCBD5E1))
            Text(valueText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
