package com.brainwavestudio.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.brainwavestudio.app.model.AmbientType
import com.brainwavestudio.app.model.AudioMode
import com.brainwavestudio.app.model.StudioState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * Ultra-pure 48kHz Stereo 32-bit Float PCM DSP Engine.
 * Uses double-precision phase accumulators for zero clicks/pops and studio-grade clarity.
 */
object PureBrainwaveEngine {
    const val SAMPLE_RATE = 48000
    private const val TWO_PI = 2.0 * PI

    private val _state = MutableStateFlow(StudioState())
    val state: StateFlow<StudioState> = _state

    // Live oscilloscope samples (64 points) for Compose Visualizer
    private val _waveform = MutableStateFlow(FloatArray(64))
    val waveform: StateFlow<FloatArray> = _waveform

    @Volatile private var running = false
    @Volatile private var targetPlaying = false
    private var audioThread: Thread? = null

    fun updateState(transform: (StudioState) -> StudioState) {
        _state.value = transform(_state.value)
    }

    fun start() {
        targetPlaying = true
        updateState { it.copy(isPlaying = true) }
        if (running) return
        running = true

        audioThread = Thread({
            val minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT
            )
            val bufferFrames = maxOf(minBuf / 8, 1024)
            val pcm = FloatArray(bufferFrames * 2)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufferFrames * 2 * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            track.play()

            var phaseL = 0.0
            var phaseR = 0.0
            var phaseIso = 0.0
            var phaseLfo = 0.0
            var phaseWarmth = 0.0

            // Smooth envelopes
            var envGain = 0.0
            var smoothCarrier = _state.value.carrierHz.toDouble()
            var smoothBeat = _state.value.beatHz.toDouble()

            // Pink & Brown noise states (Left & Right independent for natural stereo)
            val bL = DoubleArray(7)
            val bR = DoubleArray(7)
            var brownL = 0.0
            var brownR = 0.0
            var lpL = 0.0
            var lpR = 0.0
            val rng = Random.Default

            val vizPreview = FloatArray(64)

            while (running) {
                val st = _state.value
                val fadeTarget = if (targetPlaying) st.masterVol.toDouble() * 0.65 else 0.0
                val fadeStep = 1.0 / (SAMPLE_RATE * 0.9) // ~0.9s smooth fade

                val targetCarrier = st.carrierHz.toDouble()
                val targetBeat = st.beatHz.toDouble()
                val isoDepth = st.isoDepth.toDouble()
                val warmthGain = st.warmth.toDouble() * 0.22
                val ambientGain = if (st.ambientType == AmbientType.NONE) 0.0 else st.ambientVol.toDouble() * 0.45

                val binMix = when (st.mode) {
                    AudioMode.BINAURAL -> 0.60
                    AudioMode.HYBRID -> 0.38
                    AudioMode.ISOCHRONIC -> 0.0
                }
                val isoMix = when (st.mode) {
                    AudioMode.ISOCHRONIC -> 0.60
                    AudioMode.HYBRID -> 0.36
                    AudioMode.BINAURAL -> 0.0
                }

                for (i in 0 until bufferFrames) {
                    // Smooth frequency & master fade
                    smoothCarrier += (targetCarrier - smoothCarrier) * 0.0015
                    smoothBeat += (targetBeat - smoothBeat) * 0.0015

                    if (envGain < fadeTarget) envGain = minOf(fadeTarget, envGain + fadeStep)
                    else if (envGain > fadeTarget) envGain = maxOf(fadeTarget, envGain - fadeStep)

                    val leftHz = maxOf(20.0, smoothCarrier - smoothBeat / 2.0)
                    val rightHz = maxOf(20.0, smoothCarrier + smoothBeat / 2.0)

                    phaseL = (phaseL + TWO_PI * leftHz / SAMPLE_RATE) % TWO_PI
                    phaseR = (phaseR + TWO_PI * rightHz / SAMPLE_RATE) % TWO_PI
                    phaseIso = (phaseIso + TWO_PI * smoothCarrier / SAMPLE_RATE) % TWO_PI
                    phaseLfo = (phaseLfo + TWO_PI * smoothBeat / SAMPLE_RATE) % TWO_PI
                    phaseWarmth = (phaseWarmth + TWO_PI * maxOf(40.0, smoothCarrier / 2.0) / SAMPLE_RATE) % TWO_PI

                    val sinL = sin(phaseL)
                    val sinR = sin(phaseR)

                    // Smooth raised-cosine isochronic pulse (zero clicking)
                    val lfoMod = (1.0 - isoDepth / 2.0) + (isoDepth / 2.0) * sin(phaseLfo)
                    val isoSample = sin(phaseIso) * lfoMod
                    val warmthSample = sin(phaseWarmth) * warmthGain

                    // Natural stereo ambient noise
                    var ambL = 0.0
                    var ambR = 0.0
                    if (ambientGain > 0.0001) {
                        val wL = rng.nextDouble(-1.0, 1.0)
                        val wR = rng.nextDouble(-1.0, 1.0)
                        when (st.ambientType) {
                            AmbientType.PINK -> {
                                bL[0] = 0.99886 * bL[0] + wL * 0.0555179
                                bL[1] = 0.99332 * bL[1] + wL * 0.0750759
                                bL[2] = 0.96900 * bL[2] + wL * 0.1538520
                                bL[3] = 0.86650 * bL[3] + wL * 0.3104856
                                bL[4] = 0.55000 * bL[4] + wL * 0.5329522
                                bL[5] = -0.7616 * bL[5] - wL * 0.0168980
                                ambL = (bL[0] + bL[1] + bL[2] + bL[3] + bL[4] + bL[5] + bL[6] + wL * 0.5362) * 0.05
                                bL[6] = wL * 0.115926

                                bR[0] = 0.99886 * bR[0] + wR * 0.0555179
                                bR[1] = 0.99332 * bR[1] + wR * 0.0750759
                                bR[2] = 0.96900 * bR[2] + wR * 0.1538520
                                bR[3] = 0.86650 * bR[3] + wR * 0.3104856
                                bR[4] = 0.55000 * bR[4] + wR * 0.5329522
                                bR[5] = -0.7616 * bR[5] - wR * 0.0168980
                                ambR = (bR[0] + bR[1] + bR[2] + bR[3] + bR[4] + bR[5] + bR[6] + wR * 0.5362) * 0.05
                                bR[6] = wR * 0.115926
                            }
                            AmbientType.BROWN -> {
                                brownL = (brownL + 0.02 * wL) / 1.02
                                brownR = (brownR + 0.02 * wR) / 1.02
                                ambL = brownL * 1.4
                                ambR = brownR * 1.4
                            }
                            AmbientType.WHITE -> {
                                lpL += (wL * 0.2 - lpL) * 0.08
                                lpR += (wR * 0.2 - lpR) * 0.08
                                ambL = lpL
                                ambR = lpR
                            }
                            AmbientType.NONE -> {}
                        }
                    }

                    val outL = tanh((sinL * binMix + isoSample * isoMix + warmthSample + ambL * ambientGain) * envGain)
                    val outR = tanh((sinR * binMix + isoSample * isoMix + warmthSample + ambR * ambientGain) * envGain)

                    pcm[i * 2] = outL.toFloat()
                    pcm[i * 2 + 1] = outR.toFloat()

                    if (i < 64) {
                        vizPreview[i] = ((outL + outR) * 0.5).toFloat()
                    }
                }

                _waveform.value = vizPreview.copyOf()
                track.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)

                if (!targetPlaying && envGain <= 0.0005) {
                    running = false
                }
            }

            track.stop()
            track.release()
        }, "PureBrainwaveDSP").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        targetPlaying = false
        updateState { it.copy(isPlaying = false, rampActive = false) }
    }

    /** Plays a quick Left (330Hz) then Right (440Hz) pure sine test tone */
    fun playStereoEarTest() {
        Thread {
            val frames = SAMPLE_RATE // 1 second total (0.5s L, 0.5s R)
            val pcm = FloatArray(frames * 2)
            val half = frames / 2
            for (i in 0 until half) {
                val env = sin(PI * i / half) * 0.3
                pcm[i * 2] = (sin(TWO_PI * 330.0 * i / SAMPLE_RATE) * env).toFloat()
                pcm[i * 2 + 1] = 0f
            }
            for (i in 0 until half) {
                val env = sin(PI * i / half) * 0.3
                val idx = (half + i) * 2
                pcm[idx] = 0f
                pcm[idx + 1] = (sin(TWO_PI * 440.0 * i / SAMPLE_RATE) * env).toFloat()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 4)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
            track.play()
            Thread.sleep(1100)
            track.stop()
            track.release()
        }.start()
    }
}
